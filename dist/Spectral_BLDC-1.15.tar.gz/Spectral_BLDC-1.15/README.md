# Spectral-BLDC
Python lib for controlling spectral BLDC controllers.
